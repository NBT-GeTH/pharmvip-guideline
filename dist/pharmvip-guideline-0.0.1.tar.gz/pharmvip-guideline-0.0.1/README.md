# PharmVIP(Pharmacogenomic Variant Analysis and Interpretation Platform) - Guideline Module

### Allele Definitions

```shell
pharmvip_guideline allele_definitions_transform \
    --allele_definitions \
    --outputs \
    --dbpmcgenomics
```

### Allele Matcher

```shell
pharmvip_guideline allele_matcher \
    --parameter
```
