#!/usr/bin/env python

import glob
import pandas as pd
import math
import re

metabolizer_status_unique = []

for guideline in glob.glob("/Users/csukrith/801989/pharmvip/data/clinical_guideline_annotations/2019_12_03/*.xlsx"):
    guideline_annotations = pd.read_excel(guideline, sheet_name="GuidelineAnnotations")
    print(f"################ {guideline}")

    for i in guideline_annotations["MetabolizerStatus"].tolist():
        if isinstance(i, float) and math.isnan(i):
            i = "N/A"
            # print(f"{i}")
            if i not in metabolizer_status_unique:
                metabolizer_status_unique.append(i)
        else:
            i = i.replace("\n", "")
            i = re.search("(<p>)((?!<strong>)(?!<em>).*)(<\/p>)", i)
            i = i.group().split("</p>")
            while "" in i: 
                i.remove("") 
            # print(f"{i}")
            for j in i:
                j = re.search("(<p>)((?!<strong>)(?!<em>).*)", j)
                if j:
                    j = j.group().replace("<p>", "")
                    case_as = re.search("(.*)(\s\(AS)", j)
                    case_activity = re.search("(.*)(\.\sActivity)", j)
                    case_dot = re.search("(.*)(\.)", j)
                    case_for = re.search("(For\s.*:)", j)
                    if case_as:
                        case_as = case_as.group(1).title()
                        print(f"case as:\t{case_as}")
                        if case_as not in metabolizer_status_unique:
                            metabolizer_status_unique.append(case_as)
                    elif case_activity: 
                        case_activity = case_activity.group(1).title()
                        print(f"case activity:\t{case_activity}")
                        if case_activity not in metabolizer_status_unique:
                            metabolizer_status_unique.append(case_activity)
                    elif case_dot:
                        case_dot = case_dot.group(1).title()
                        print(f"case dot:\t{case_dot}")
                        if case_dot not in metabolizer_status_unique:
                            metabolizer_status_unique.append(case_dot)
                    elif case_for:
                        pass
                    else:
                        case_normal = j.title()
                        if case_normal == "Ultrarapid Metabolizer" or case_normal == "Ultra Rapid Metabolizer":
                            case_normal = "Ultra Rapid Metabolizer"
                        print(f"case normal:\t{case_normal}")
                        if case_normal not in metabolizer_status_unique:
                            metabolizer_status_unique.append(case_normal)
    
    print(f"{'-' * 160}")

print(f"################ Metabolizer Status Unique:")
metabolizer_status_unique.sort()
count = 1
for i in metabolizer_status_unique:
    print(f"{count}\t{i}")
    count += 1
print(f"{'-' * 160}")
